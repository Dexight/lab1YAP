using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Starpower : MonoBehaviour
{
    private void Start()
    {
    }

    private void Update()
    {
    }
}
